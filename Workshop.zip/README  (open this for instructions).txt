STEPS TO BE FOLLOWED TO MODIFY PYTHON CODE:

1. Extract the zip, and open the folder directory in vscode (or any other), in my case directory is-  C:\Workshop

2.Install the pacakges, I have included all necessary packages in requirements.txt, so install by 
	
	pip install -r <path to requiremnets.txt>

3. pip install ngrok (exact folder should be open in vscode)

4. execute the following: ngrok http 5000    

	you might get some errors and they will ask u to signup and authenticate, if u're doing it for 1st time. the setps are straightforward and explained in the website itself.

	after authenticating, execute ngrok http 5000, now u will see details about ur port forwarding ip.

5. Make a telegram bot, by using bot_father in telegram (just search in telegram)
	after making the bot, u will get a bot token,
	
	replace "bot_token=YOUR_TOKEN_HERE" with actual token (in line 29 of program)   

6.Generate Chat ID of ur telegram bot:

 simply open any browser and type : https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getUpdates (REPLACE <YOUR_BOT_TOKEN> with actual token)

	then u will get a response on ur browser, it will contain chat id , it might be n format:
				
											chat":{"id":5000451728,"first_name":"Nithin"

7. once u have obtained chat id, replace "chat_id = Your_chat_id" with actual chat id (on line 31 of python code)


8. Now check path specified for .tflite file:

	check line 135 of code:

		model = YOLO(r"C:/Workshop/best_float32.tflite")     ----make sure that path is correct



STEPS TO MODIFY ESP32 CODE:

1. install all required library (u can install from aurdino ide itself)

2.modify "wifi_ssid" and "wifi_password" on line 11 & 12

3. in this code, the buzzer pin is set to 4, make sure to connect data pin of buzzer to pin 4 of esp32.


THATS IT!, 

Now after flashing the code to esp32, u can run the python code and connect esp32 to powersource, once the camera detecets a person, it will turn on the buzzer. 

u will also revive a link on ur telegram bot, from which u can watch the live steam from camera, from any part of the world !
		


